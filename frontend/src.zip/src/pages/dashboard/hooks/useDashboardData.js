import { useEffect, useState } from "react";
import { apiRequest } from "../../../lib/api";

export function useDashboardData({ mode, date }) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);

    apiRequest(`/api/dashboard?mode=${mode}&date=${date.toISOString()}`)
      .then(setData)
      .finally(() => setLoading(false));
  }, [mode, date]);

  return { data, loading };
}
