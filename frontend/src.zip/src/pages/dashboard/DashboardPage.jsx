import DashboardLayout from "./DashboardLayout";
import { useDashboardData } from "./hooks/useDashboardData";

import SummaryCards from "./components/SummaryCards";
import SpendingLineChart from "./components/SpendingLineChart";
import CategoryDonut from "./components/CategoryDonut";
import CategoryTable from "./components/CategoryTable";
import CategoryDrawer from "./components/CategoryDrawer";
import InsightsPanel from "./components/InsightsPanel";

import { useState } from "react";

export default function DashboardPage() {
  const [mode, setMode] = useState("month");
  const [date, setDate] = useState(new Date());

  const { data, loading } = useDashboardData({ mode, date });

  const [drawerOpen, setDrawerOpen] = useState(false);
  const [activeCategory, setActiveCategory] = useState(null);

  if (loading || !data) {
    return <div className="text-white p-6">Loading dashboard…</div>;
  }

  return (
    <DashboardLayout>
      <SummaryCards totals={data.totals} mode={mode} />

      <div className="mt-6 grid gap-6 lg:grid-cols-12">
        <div className="lg:col-span-8 space-y-6">
          <SpendingLineChart series={data.series} mode={mode} />

          <div className="grid gap-6 md:grid-cols-2">
            <CategoryDonut
              categories={data.categories}
              onInfo={(c) => {
                setActiveCategory(c);
                setDrawerOpen(true);
              }}
            />
            <InsightsPanel totals={data.totals} mode={mode} />
          </div>
        </div>

        <div className="lg:col-span-4">
          <CategoryTable
            categories={data.categories}
            onInfo={(c) => {
              setActiveCategory(c);
              setDrawerOpen(true);
            }}
          />
        </div>
      </div>

      <CategoryDrawer
        open={drawerOpen}
        category={activeCategory}
        onClose={() => setDrawerOpen(false)}
      />
    </DashboardLayout>
  );
}
