import Sidebar from "./components/Sidebar";
import TopBar from "./components/TopBar";

export default function DashboardLayout({ children }) {
  return (
    <div className="flex min-h-screen bg-gradient-to-b from-[#071b13] to-[#04110c] text-white">
      <Sidebar />

      <div className="flex flex-1 flex-col">
        <TopBar />
        <main className="flex-1 px-6 py-6">{children}</main>
      </div>
    </div>
  );
}
