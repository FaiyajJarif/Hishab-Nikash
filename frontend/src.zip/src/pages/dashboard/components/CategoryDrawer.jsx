import { AnimatePresence, motion } from "framer-motion";

export default function CategoryDrawer({ open, category, onClose }) {
  return (
    <AnimatePresence>
      {open ? (
        <>
          <motion.div
            className="fixed inset-0 z-40 bg-black/60"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
          />

          <motion.div
            className="fixed right-0 top-0 z-50 h-full w-full max-w-md bg-[#061a12] ring-1 ring-white/10 shadow-[0_30px_80px_rgba(0,0,0,0.55)]"
            initial={{ x: 420 }}
            animate={{ x: 0 }}
            exit={{ x: 420 }}
            transition={{ type: "spring", stiffness: 320, damping: 28 }}
          >
            <div className="flex items-center justify-between border-b border-white/10 px-6 py-5">
              <div>
                <div className="text-lg font-extrabold text-white/95">{category?.name || "Category"}</div>
                <div className="mt-1 text-xs text-white/60">Details & activity</div>
              </div>
              <button
                onClick={onClose}
                className="grid h-10 w-10 place-items-center rounded-2xl bg-white/10 ring-1 ring-white/10 hover:bg-white/15 transition"
              >
                ✕
              </button>
            </div>

            <div className="px-6 py-6 space-y-5">
              <StatRow label="Assigned" value={money(category?.assigned)} />
              <StatRow label="Spent" value={money(category?.spent)} />
              <StatRow label="Available" value={money(category?.available)} emphasis={category?.available < 0 ? "bad" : "good"} />

              <div className="rounded-3xl bg-white/5 p-4 ring-1 ring-white/10">
                <div className="text-xs font-semibold uppercase tracking-wider text-white/60">Goal</div>
                {category?.goal?.enabled ? (
                  <div className="mt-2 space-y-1">
                    <div className="text-sm text-white/80">Target: <span className="text-lime-200 font-semibold">{money(category.goal.target)}</span></div>
                    <div className="text-sm text-white/80">Progress: <span className="text-white/90 font-semibold">{money(category.goal.progress)}</span></div>
                    <div className="mt-3 h-2 rounded-full bg-white/10 overflow-hidden">
                      <div
                        className="h-full bg-lime-300 transition-all"
                        style={{
                          width: `${Math.min(100, Math.round((category.goal.progress / category.goal.target) * 100))}%`,
                        }}
                      />
                    </div>
                    <div className="mt-2 text-xs text-white/55">Keep it up — you’re building momentum.</div>
                  </div>
                ) : (
                  <div className="mt-2 text-sm text-white/70">No goal set for this category yet.</div>
                )}
              </div>

              <div className="rounded-3xl bg-white/5 p-4 ring-1 ring-white/10">
                <div className="text-xs font-semibold uppercase tracking-wider text-white/60">Family activity</div>
                <div className="mt-2 flex flex-wrap gap-2">
                  {(category?.family || []).length ? (
                    category.family.map((m) => (
                      <span key={m} className="rounded-full bg-white/10 px-3 py-1 text-xs text-white/80 ring-1 ring-white/10">
                        {m}
                      </span>
                    ))
                  ) : (
                    <span className="text-sm text-white/65">No family activity found.</span>
                  )}
                </div>
                <div className="mt-3 text-xs text-white/55">
                  Idea: show “Top spender”, “Last transaction”, and “Role badge” here.
                </div>
              </div>

              <div className="grid gap-3 sm:grid-cols-2">
                <button className="rounded-2xl bg-lime-300 px-4 py-3 text-sm font-semibold text-[#061a12] hover:bg-lime-200 transition">
                  Assign money
                </button>
                <button className="rounded-2xl bg-white/10 px-4 py-3 text-sm ring-1 ring-white/15 hover:bg-white/15 transition">
                  View transactions
                </button>
              </div>
            </div>
          </motion.div>
        </>
      ) : null}
    </AnimatePresence>
  );
}

function StatRow({ label, value, emphasis }) {
  const color =
    emphasis === "bad" ? "text-red-200" : emphasis === "good" ? "text-lime-200" : "text-white/90";

  return (
    <div className="flex items-center justify-between rounded-3xl bg-white/5 px-4 py-3 ring-1 ring-white/10">
      <div className="text-sm text-white/70">{label}</div>
      <div className={["text-sm font-extrabold", color].join(" ")}>{value}</div>
    </div>
  );
}

function money(n) {
  if (n === undefined || n === null) return "—";
  const sign = n < 0 ? "-" : "";
  const v = Math.abs(n);
  return `${sign}৳${v.toLocaleString()}`;
}
