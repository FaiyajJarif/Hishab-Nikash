import { NavLink, useNavigate } from "react-router-dom";
import { useAuth } from "../../../context/AuthContext";

export default function Sidebar() {
  const { logout } = useAuth();
  const navigate = useNavigate();

  return (
    <aside className="w-64 shrink-0 border-r border-white/10 bg-[#061a12] px-4 py-6">
      <div className="text-xl font-extrabold text-lime-200 mb-8">
        Hishab Nikash
      </div>

      <nav className="space-y-2">
        <NavItem to="/dashboard">Dashboard</NavItem>
        <NavItem to="/dashboard/profile">Profile</NavItem>
        <NavItem to="/dashboard/family">Family</NavItem>
        <NavItem to="/dashboard/banking">Banking</NavItem>
        <NavItem to="/dashboard/subscriptions">Subscriptions</NavItem>
      </nav>

      <button
        onClick={() => {
          logout();
          navigate("/login");
        }}
        className="mt-10 w-full rounded-2xl bg-white/10 px-4 py-3 text-sm ring-1 ring-white/15 hover:bg-white/15 transition"
      >
        Logout
      </button>
    </aside>
  );
}

function NavItem({ to, children }) {
  return (
    <NavLink
      to={to}
      className={({ isActive }) =>
        [
          "block rounded-2xl px-4 py-3 text-sm transition",
          isActive
            ? "bg-lime-300 text-[#061a12] font-semibold"
            : "text-white/75 hover:bg-white/10",
        ].join(" ")
      }
    >
      {children}
    </NavLink>
  );
}
